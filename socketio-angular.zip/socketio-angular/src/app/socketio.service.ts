import { Injectable } from '@angular/core';
import { io } from 'socket.io-client';
import { environment } from '../enviroment';

@Injectable({
  providedIn: 'root'
})
export class SocketioService {

  socket: any;
  constructor() {   }

  setupSocketConnection(token: string) {
    this.socket = io(environment.SOCKET_ENDPOINT, {
      auth: {
        token
      }
    });
  }

  // Handle message receive event
  subscribeToMessages = (cb: any) => {
    if (!this.socket) return(true);
    this.socket.on('message', (msg : any) => {
      console.log('Room event received!');
      return cb(null, msg);
    });
    return true;
  }

  sendMessage = ({message , roomName} : {message: any, roomName: any}, cb: any) => {
    if (this.socket) this.socket.emit('message', { message, roomName }, cb);
  }

  joinRoom = (roomName: any) => {
    this.socket.emit('join', roomName);
  }
  
  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
    }
  }
}
