export const environment = {  
	production: false,  
	SOCKET_ENDPOINT: 'http://192.168.1.6:3000'
};